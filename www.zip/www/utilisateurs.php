<!DOCTYPE html>

<html>
<head>
  <title>DJEMS Automobile</title>
  <meta charset= "UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/vendors/fontawesome/css/all.min.css"> 
  <link rel="stylesheet" href="styles.css">

  <style>
    /* Styles spécifiques pour cette page */
    .image-top-right {
      float: right;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }
    .social-icons a {
      color: #000;
      transition: color 0.3s;
    }
    .social-icons a:hover {
      color: #2196F3;
    }
    .card {
      background-color: #f8f9fa;
      border: none;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s;
    }
    .card:hover {
      box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
    }
    .card-img-top {
      border-radius: 10px 10px 0 0;
    }
    .card-body {
      padding: 20px;
    }
    .card-title {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .card-text {
      margin-bottom: 20px;
    }
    .card-link {
      color: #2196F3;
      font-weight: bold;
      transition: color 0.3s;
    }
    .card-link:hover {
      color: #0d47a1;
    }
       .footer {
      background-color: #588;
      padding: 50px 0;
      color: #fff;
      font-family: 'Roboto', sans-serif;
    }

    .footer-content {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    .footer-section {
      flex: 1 1 300px;
      margin-bottom: 30px;
    }

    .footer-section h4 {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .footer-section p {
      font-size: 14px;
      line-height: 1.6;
    }

    .footer-links {
      display: flex;
      flex-wrap: wrap;
      margin-top: 10px;
    }

    .footer-links a {
      color: #fff;
      text-decoration: none;
      margin-right: 15px;
      font-size: 14px;
      transition: color 0.3s;
    }

    .footer-links a:hover {
      color: #2196F3;
    }

    .footer-social-icons {
      display: flex;
      align-items: center;
      margin-top: 20px;
    }

    .footer-social-icons a {
      color: #fff;
      text-decoration: none;
      margin-right: 10px;
      font-size: 24px;
      transition: color 0.3s;
    }

    .footer-social-icons a:hover {
      color: #2196F3;
    }

    .footer-bottom {
      background-color: #333;
      padding: 20px 0;
      font-size: 12px;
    }

    .footer-bottom p {
      margin-bottom: 0;
    }

    .footer-bottom a {
      color: #fff;
      text-decoration: none;
      transition: color 0.3s;
    }

    .footer-bottom a:hover {
      color: #2196F3;
    }

/* Styles pour les écrans de petite taille */
@media (max-width: 768px) {
  /* Styles pour les écrans de petite taille */
}

/* Styles pour les écrans de taille moyenne */
@media (min-width: 769px) and (max-width: 1024px) {
  /* Styles pour les écrans de taille moyenne */
}

/* Styles pour les écrans de grande taille */
@media (min-width: 1025px) {
  /* Styles pour les écrans de grande taille */
}


  </style>

  <?php
// Connexion à la base de données
$bdd = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', 'root', '');


// Appel de la procédure stockée pour récupérer la liste des utilisateurs
$requete = $bdd->prepare("CALL listeUtilisateurs()");
$requete->execute();

// Récupération des résultats de la procédure
$listeUtilisateurs = $requete->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Liste des utilisateurs</title>
</head>
<body>
    <h1>Liste des utilisateurs</h1>

    <table>
        <tr>
            <th>Pseudos</th>
 
        </tr>
        <?php foreach ($listeUtilisateurs as $utilisateur) { ?>
            <tr>
                <td><?php echo $utilisateur['pseudo']; ?></td>

            </tr>
        <?php } ?>
    </table>
</body>
</html>


  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div id="about" class="footer-section">
          <h4>A propos de DJEMS AUTO</h4>
          <p>Notre site de vente de voitures est une plateforme spécialisée dans l'achat et la vente de véhicules neufs et d'occasion. Nous nous engageons à offrir à nos clients une expérience exceptionnelle, en mettant à leur disposition une large gamme de voitures de différentes marques, modèles et catégories.</p>
     
        </div>
        <div class="footer-section">
          <h4>Nos services</h4>
          <p> <li>Achat de voitures   <li>Évaluation et reprise     <li>Service après-vente   <li> Conseils d'experts </li></li></li></li></p>
     
        </div>
        <div class="footer-section">
          <h4>Notre page</h4>
          <div class="footer-links">
            <a href="#homepage">Accueil</a>
            <a href="#vehicles">Véhicules</a>
            <a href="#financing">Financement</a>
            <a href="#connexion">Connexion</a>
            <a href="politique.html">Politique de confidentialite</a>
          </div>
        </div>
        <div class="footer-section">
          <h4>Suivez-nous</h4>
          <p>Restez et profitez avec nos dernières nouvelles et offres spéciales.</p>
          <div class="footer-social-icons">

          <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook"></i></a>
          <a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://www.youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
           
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>