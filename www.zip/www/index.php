<!DOCTYPE html>

<html>
<head>
  <title>DJEMS Automobile</title>
  <meta charset= "UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/vendors/fontawesome/css/all.min.css"> 
  <link rel="stylesheet" href="styles.css">

  <style>
    /* Styles spécifiques pour cette page */
    .image-top-right {
      float: right;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }
    .social-icons a {
      color: #000;
      transition: color 0.3s;
    }
    .social-icons a:hover {
      color: #2196F3;
    }
    .card {
      background-color: #f8f9fa;
      border: none;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s;
    }
    .card:hover {
      box-shadow: 0 0 30px rgba(0, 0, 0, 0.2);
    }
    .card-img-top {
      border-radius: 10px 10px 0 0;
    }
    .card-body {
      padding: 20px;
    }
    .card-title {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .card-text {
      margin-bottom: 20px;
    }
    .card-link {
      color: #2196F3;
      font-weight: bold;
      transition: color 0.3s;
    }
    .card-link:hover {
      color: #0d47a1;
    }
       .footer {
      background-color: #588;
      padding: 50px 0;
      color: #fff;
      font-family: 'Roboto', sans-serif;
    }

    .footer-content {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    .footer-section {
      flex: 1 1 300px;
      margin-bottom: 30px;
    }

    .footer-section h4 {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .footer-section p {
      font-size: 14px;
      line-height: 1.6;
    }

    .footer-links {
      display: flex;
      flex-wrap: wrap;
      margin-top: 10px;
    }

    .footer-links a {
      color: #fff;
      text-decoration: none;
      margin-right: 15px;
      font-size: 14px;
      transition: color 0.3s;
    }

    .footer-links a:hover {
      color: #2196F3;
    }

    .footer-social-icons {
      display: flex;
      align-items: center;
      margin-top: 20px;
    }

    .footer-social-icons a {
      color: #fff;
      text-decoration: none;
      margin-right: 10px;
      font-size: 24px;
      transition: color 0.3s;
    }

    .footer-social-icons a:hover {
      color: #2196F3;
    }

    .footer-bottom {
      background-color: #333;
      padding: 20px 0;
      font-size: 12px;
    }

    .footer-bottom p {
      margin-bottom: 0;
    }

    .footer-bottom a {
      color: #fff;
      text-decoration: none;
      transition: color 0.3s;
    }

    .footer-bottom a:hover {
      color: #2196F3;
    }

/* Styles pour les écrans de petite taille */
@media (max-width: 768px) {
  /* Styles pour les écrans de petite taille */
}

/* Styles pour les écrans de taille moyenne */
@media (min-width: 769px) and (max-width: 1024px) {
  /* Styles pour les écrans de taille moyenne */
}

/* Styles pour les écrans de grande taille */
@media (min-width: 1025px) {
  /* Styles pour les écrans de grande taille */
}


  </style>

<input id="searchInput" type="text" placeholder="Rechercher un élément">
<select id="suggestionsList"></select>
<button id="searchButton">Rechercher</button>


</head>
  <script>

// Tableau d'éléments sur la page
const elements = [
  "IceSpice 250",
  "BlueFire-Vty",
  "NfS-Obsidia",
  "RTX-360",
  "Futura-gray",
  "Black Pantera 3600"
  // Ajoutez d'autres éléments sur la page
];


// Élément input pour la recherche
const searchInput = document.getElementById("searchInput");

// Élément select pour les suggestions
const suggestionsList = document.getElementById("suggestionsList");

// Bouton de recherche
const searchButton = document.getElementById("searchButton");

// Fonction pour effectuer la recherche et afficher les suggestions
function searchElements() {
  const searchTerm = searchInput.value.toLowerCase();
  const suggestions = elements.filter(element =>
    element.toLowerCase().includes(searchTerm)
  );
  displaySuggestions(suggestions);
}

// Fonction pour afficher les suggestions
function displaySuggestions(suggestions) {
  suggestionsList.innerHTML = "";
  suggestions.forEach(suggestion => {
    const option = document.createElement("option");
    option.text = suggestion;
    suggestionsList.add(option);
  });
}

// Fonction pour naviguer vers l'élément sélectionné
function navigateToElement() {
  const selectedElement = suggestionsList.value;
  if (selectedElement) {
    const element = document.getElementById(selectedElement);
    element.scrollIntoView({ behavior: "smooth" });
  }
}

// Événement de saisie dans l'input pour déclencher la recherche
searchInput.addEventListener("input", searchElements);

// Événement de clic sur le bouton de recherche
searchButton.addEventListener("click", navigateToElement);
</script>


<body>

  <!-- Header -->
  <header>
    <nav id="homepage" class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#about">
        <img src="logo.jpg" alt="DJEMS AUTO" height="30">
        <b>DJEMS AUTO
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Accueill</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="vehicules.php">Les véhicules</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="finance.html">Offres de financement</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="connexion.html">Connexion</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="administration.php">Administration</a>
          </li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- Carousel -->
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner ">

      <?php
      // Adapter dbname et mot de passe si besoin
      $username = "root";
      $password = "";

      try {
          $pdo = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', $username, $password);
      } catch (PDOException $e) {
          echo "Erreur de connexion : " . $e->getMessage();
      }

      $query = "SELECT urlImage FROM produits";
      $stmt = $pdo->query($query);
      $query1 = "SELECT description FROM produits";
      $stmt1 = $pdo->query($query1);
      $query2 = "SELECT nom FROM produits";
      $stmt2 = $pdo->query($query2);
      $query3 = "SELECT carousel FROM produits";
      $stmt3 = $pdo->query($query3);


      while ($row = $stmt->fetch(PDO::FETCH_ASSOC) and $row1 = $stmt1->fetch(PDO::FETCH_ASSOC)  and $row2 = $stmt2->fetch(PDO::FETCH_ASSOC) and $row3 = $stmt3->fetch(PDO::FETCH_ASSOC) ) {
          $imageLink = $row['urlImage'];
          $description = $row1['description'];
          $nom = $row2['nom'];
          $carousel = $row3['carousel'];

          echo '  
            <div class="carousel-item '.$carousel.'">
                    <img src="'.$imageLink.'" class="d-block w-100"  >
                    <div class="carousel-caption d-none d-md-block">
                      <h3>'.$nom.'</h3>
                      <p>'.$description.'.</p>
                      <a href="vehicules.php" class="btn btn-primary">Voir plus</a>
                    </div>
                  </div>
                      ';
      }

      $pdo = null;
      ?>
      
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>



<section id="vehicles" class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">Les Véhicules</h2>
      <div class="row">
      <?php
      // Adapter dbname et mot de passe si besoin
      $username = "root";
      $password = "";

      try {
          $pdo = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', $username, $password);
      } catch (PDOException $e) {
          echo "Erreur de connexion : " . $e->getMessage();
      }

      $query = "SELECT urlImage FROM produits";
      $stmt = $pdo->query($query);
      $query1 = "SELECT description FROM produits";
      $stmt1 = $pdo->query($query1);
      $query2 = "SELECT nom FROM produits";
      $stmt2 = $pdo->query($query2);



      while ($row = $stmt->fetch(PDO::FETCH_ASSOC) and $row1 = $stmt1->fetch(PDO::FETCH_ASSOC)  and $row2 = $stmt2->fetch(PDO::FETCH_ASSOC) ) {
          $imageLink = $row['urlImage'];
          $description = $row1['description'];
          $nom = $row2['nom'];

          echo '  
              <div id="'.$nom. '" class="col-md-4">
                <div class="card mb-4">
                  <img src="' . $imageLink . '" class="card-img-top">
                  <div class="card-body">
                    <h5 class="card-title">'. $nom .'</h5>
                    <p class="card-text">'.$description.'</p>
                    <a href="finance.html" class="card-link">En savoir plus</a>
                  </div>
                </div>
              </div>
                      ';
      }

      $pdo = null;
      ?>

      </div>
  </div>
</section>

 


  <!-- Offres de financement -->
  <section id="financing" class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-5">Offres de Financement</h2>
      <div class="row">
        <div class="col-md-6">
          <img src="image.jpg" class="img-fluid image-top-right" alt="Financement">
        </div>
        <div class="col-md-6">
          <h3>Financement Flexible</h3>
          <p>Nous proposons des options de financement flexibles pour vous aider à acheter votre voiture de rêve.</p>
          <ul>
            <li>Prêt avec un faible taux d'intérêt</li>
            <li>Paiements mensuels abordables</li>
            <li>Processus de demande simple et rapide</li>
          </ul>
          <a href="finance.html" class="btn btn-primary">En savoir plus</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Enregistrez-vous -->
  <section id="connexion" class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">Enregistrez-vous</h2>
      <div class="row">
        <div class="col-md-6">
      <form method="post" action="scriptInscription.php" >
          <label for="pseudo">Pseudo :</label>
          <input type="pseudo" id="pseudo" name="pseudo" required><br>
          <label for="password">Mot de passe :</label>
          <input type="motDePasse" id="motDePasse" name="motDePasse" required><br>
          <input type="submit" value="Se connecter">
      </form>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div id="about" class="footer-section">
          <h4>A propos de DJEMS AUTO</h4>
          <p>Notre site de vente de voitures est une plateforme spécialisée dans l'achat et la vente de véhicules neufs et d'occasion. Nous nous engageons à offrir à nos clients une expérience exceptionnelle, en mettant à leur disposition une large gamme de voitures de différentes marques, modèles et catégories.</p>
     
        </div>
        <div class="footer-section">
          <h4>Nos services</h4>
          <p> <li>Achat de voitures   <li>Évaluation et reprise     <li>Service après-vente   <li> Conseils d'experts </li></li></li></li></p>
     
        </div>
        <div class="footer-section">
          <h4>Notre page</h4>
          <div class="footer-links">
            <a href="#homepage">Accueil</a>
            <a href="#vehicles">Véhicules</a>
            <a href="#financing">Financement</a>
            <a href="#connexion">Connexion</a>
            <a href="politique.html">Politique de confidentialite</a>
          </div>
        </div>
        <div class="footer-section">
          <h4>Suivez-nous</h4>
          <p>Restez et profitez avec nos dernières nouvelles et offres spéciales.</p>
          <div class="footer-social-icons">

          <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook"></i></a>
          <a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://www.youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
           
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>