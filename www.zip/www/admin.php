<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Page d'administration</title>
  <link rel="stylesheet" href="admin.css">

  <style>
  /* Réinitialisation des styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Styles généraux */
body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
  color: #333;
}

header {
  background-color: #222;
  padding: 20px;
  color: #fff;
}

header h1 {
  font-size: 24px;
}

nav ul {
  list-style-type: none;
}

nav ul li {
  display: inline-block;
  margin-right: 10px;
}

nav ul li a {
  color: #fff;
  text-decoration: none;
}

main {
  margin: 20px;
}

h2 {
  font-size: 20px;
  margin-bottom: 10px;
}

button {
  background-color: #333;
  color: #fff;
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

table th, table td {
  padding: 8px;
  border-bottom: 1px solid #ccc;
}

table th {
  background-color: #f2f2f2;
  font-weight: bold;
  text-align: left;
}

footer {
  text-align: center;
  padding: 10px;
}

</style>
</head>
<body>
  <header>
    <h1>Administration</h1>
    <nav>
      <ul>
        <li><a href="#">Accueil</a></li>
        <li><a href="#">Produits</a></li>
        <li><a href="#">Utilisateurs</a></li>
        <li><a href="#">Déconnexion</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <h2>Gestion des produits</h2>
    <button id="btnAjouterProduit">Ajouter un produit</button>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nom</th>
          <th>Prix</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Les données des produits seront ajoutées dynamiquement ici -->
      </tbody>
    </table>
  </main>

  <footer>
    <p>© 2024 Votre entreprise. Tous droits réservés.</p>
  </footer>
</body>
</html>

<?php
// Vérifier le statut d'administrateur de l'utilisateur connecté
session_start(); // Démarrer la session (si ce n'est pas déjà fait)

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    // Rediriger l'utilisateur vers une page d'erreur d'accès non autorisé
    header('Location: error.php');
    exit;
}

// Créer une connexion à la base de données
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'wsprosit5';

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die('Erreur de connexion à la base de données : ' . mysqli_connect_error());
}

// Exécuter une procédure stockée
$procedureName = 'listeVoitures';


$query = "CALL $procedureName()";

$result = mysqli_query($conn, $query);

if (!$result) {
    die('Erreur lors de l\'exécution de la procédure stockée : ' . mysqli_error($conn));
}

// Traiter le résultat de la procédure stockée ici...

// Fermer la connexion à la base de données
mysqli_close($conn);
?>