
<?php
// Adapter dbname et mot de passe si besoin
$bdd = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', 'root', '');

// Récupération des données utilisateurs
$nom = $_POST['nom'];
$prix = $_POST['prix'];
$description = $_POST['description'];
$solde = $_POST['solde'];
$urlImage = $_POST['urlImage'];
// Vérification du nom de la voiture
$requeteVerifPseudo = $bdd->prepare("SELECT COUNT(*) AS count FROM produits WHERE nom = :nom");
$requeteVerifPseudo->bindValue(':nom', $nom, PDO::PARAM_STR);
$requeteVerifPseudo->execute();
$resultatVerifPseudo = $requeteVerifPseudo->fetch(PDO::FETCH_ASSOC);

if ($resultatVerifPseudo['count'] > 0) {
    // Le pseudo est déjà utilisé, afficher un message d'erreur ou effectuer une action appropriée
    echo "Cette voiture a deja ete ajoutee.";
} else {
    // Le pseudo est disponible, procéder à l'insertion dans la base de données
    // ...

// Requête préparée pour empêcher les injections SQL
$requete = $bdd->prepare("CALL nouvelleVoiture(:nom, :prix, :description, :solde, :urlImage)");

// Liaison des variables de la requête préparée aux variables php
$requete->bindValue(':nom', $nom, PDO::PARAM_STR);
$requete->bindValue(':prix', $prix, PDO::PARAM_STR);
$requete->bindValue(':description', $description, PDO::PARAM_STR);
$requete->bindValue(':solde', $solde, PDO::PARAM_STR);
$requete->bindValue(':urlImage', $urlImage, PDO::PARAM_STR);


// Exécution de la requête préparée avec les données liées
$requete->execute();
header('Location: index.php');
exit();
}

?>