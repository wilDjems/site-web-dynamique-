<?php
// ...
// Adapter dbname et mot de passe si besoin
$bdd = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', 'root', '');

// Vérification des informations de connexion
$pseudo = $_POST['pseudo'];
$motDePasse = $_POST['motDePasse'];

$requeteVerifConnexion = $bdd->prepare("SELECT COUNT(*) AS count FROM utilisateurs WHERE pseudo = :pseudo AND motDePasse = :motDePasse");
$requeteVerifConnexion->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
$requeteVerifConnexion->bindValue(':motDePasse', $motDePasse, PDO::PARAM_STR);
$requeteVerifConnexion->execute();
$resultatVerifConnexion = $requeteVerifConnexion->fetch(PDO::FETCH_ASSOC);

if ($resultatVerifConnexion['count'] > 0) {
    // Les informations de connexion sont valides, l'utilisateur est connecté
    echo "Connexion réussie !";
    // Effectuez ici d'autres actions appropriées après la connexion réussie
    header('Location: index.php');
    exit();
} else {
    // Les informations de connexion sont invalides, afficher un message d'erreur ou effectuer une action appropriée
    echo "Identifiants invalides. Veuillez réessayer.";
}

// ...

?>