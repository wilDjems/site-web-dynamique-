
<?php
// Adapter dbname et mot de passe si besoin
$bdd = new PDO('mysql:host=localhost;dbname=wsprosit5;charset=utf8', 'root', '');

// R�cup�ration des donn�es utilisateurs
$pseudo = $_POST['pseudo'];
$motDePasse = $_POST['motDePasse'];
// V�rification du pseudo
$requeteVerifPseudo = $bdd->prepare("SELECT COUNT(*) AS count FROM utilisateurs WHERE pseudo = :pseudo");
$requeteVerifPseudo->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
$requeteVerifPseudo->execute();
$resultatVerifPseudo = $requeteVerifPseudo->fetch(PDO::FETCH_ASSOC);

if ($resultatVerifPseudo['count'] > 0) {
    // Le pseudo est d�j� utilis�, afficher un message d'erreur ou effectuer une action appropri�e
    echo "Ce pseudo est d�j� utilis� par un autre utilisateur.";
} else {
    // Le pseudo est disponible, proc�der � l'insertion dans la base de donn�es
    // ...

// Requ�te pr�par�e pour emp�cher les injections SQL
$requete = $bdd->prepare("INSERT INTO utilisateurs (pseudo, motDePasse) VALUES(:pseudo, :motDePasse)");

// Liaison des variables de la requ�te pr�par�e aux variables php
$requete->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
$requete->bindValue(':motDePasse', $motDePasse, PDO::PARAM_STR);



// Ex�cution de la requ�te pr�par�e avec les donn�es li�es
$requete->execute();
header('Location: index.php');
exit();
}

?>