<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/vendors/fontawesome/css/all.min.css"> 
  <title>Page d'administration</title>

  <style>
  /* Réinitialisation des styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Styles généraux */
body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
  color: #333;
}

header {
  background-color: #222;
  padding: 20px;
  color: #fff;
}

header h1 {
  font-size: 24px;
}

nav ul {
  list-style-type: none;
}

nav ul li {
  display: inline-block;
  margin-right: 10px;
}

nav ul li a {
  color: #fff;
  text-decoration: none;
}

main {
  margin: 20px;
}

h2 {
  font-size: 20px;
  margin-bottom: 10px;
}

button {
  background-color: #333;
  color: #fff;
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

table th, table td {
  padding: 8px;
  border-bottom: 1px solid #ccc;
}

table th {
  background-color: #f2f2f2;
  font-weight: bold;
  text-align: left;
}

footer {
  text-align: center;
  padding: 10px;
}

</style>
</head>
<body>
  <header>
    <h1>Administration</h1>
    <nav>
      <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="vehicules.php">Nos Vehicules</a></li>
        <li><a href="utilisateurs.php">Utilisateurs</a></li>
        <li><a href="index.php">Déconnexion</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <h2>Gestion des produits</h2>

  <section id="connexion" class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">Ajoutez un produit</h2>
      <div class="row">
        <div class="col-md-6">
      <form method="post" action="scriptVoiture.php" >
          <label for="nom">Nom :</label>
          <input type="nom" id="nom" name="nom" required><br>
          <label for="prix">Prix :</label>
          <input type="prix" id="prix" name="prix" required><br>
          <label for="description">Description :</label>
          <input type="description" id="description" name="description" required><br>
          <label for="solde">Solde :</label>
          <input type="solde" id="solde" name="solde" required><br>
          <label for="urlImage">UrlImage :</label>
          <input type="urlImage" id="urlImage" name="urlImage" required><br>
          <button id="btnAjouterProduit" type="submit"> Ajouter un produit</button>
      </form>
        <!-- Les données des produits seront ajoutées dynamiquement ici -->

        <?php
        // Vérifier le statut d'administrateur de l'utilisateur connecté


        // Créer une connexion à la base de données
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'wsprosit5';

        $conn = mysqli_connect($host, $user, $password, $database);

        if (!$conn) {
            die('Erreur de connexion à la base de données : ' . mysqli_connect_error());
        }

        // Exécuter une procédure stockée
        $procedureName = 'listeVoitures';


        $query = "CALL $procedureName()";

        $result = mysqli_query($conn, $query);

        if (!$result) {
            die('Erreur lors de l\'exécution de la procédure stockée : ' . mysqli_error($conn));
        }

        // Traiter le résultat de la procédure stockée ici...

        // Fermer la connexion à la base de données
        mysqli_close($conn);
        ?>

  <footer>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div id="about" class="footer-section">
          <h4>A propos de DJEMS AUTO</h4>
          <p>Notre site de vente de voitures est une plateforme spécialisée dans l'achat et la vente de véhicules neufs et d'occasion. Nous nous engageons à offrir à nos clients une expérience exceptionnelle, en mettant à leur disposition une large gamme de voitures de différentes marques, modèles et catégories.</p>
     
        </div>
        <div class="footer-section">
          <h4>Nos services</h4>
          <p> <li>Achat de voitures   <li>Évaluation et reprise     <li>Service après-vente   <li> Conseils d'experts </li></li></li></li></p>
     
        </div>
        <div class="footer-section">
          <h4>Notre page</h4>
          <div class="footer-links">
            <a href="#homepage">Accueil</a>
            <a href="#vehicles">Véhicules</a>
            <a href="#financing">Financement</a>
            <a href="#connexion">Connexion</a>
            <a href="politique.html">Politique de confidentialite</a>
          </div>
        </div>
        <div class="footer-section">
          <h4>Suivez-nous</h4>
          <p>Restez et profitez avec nos dernières nouvelles et offres spéciales.</p>
          <div class="footer-social-icons">

          <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook"></i></a>
          <a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://www.youtube.com/" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
      </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </footer>
</body>
</html>
